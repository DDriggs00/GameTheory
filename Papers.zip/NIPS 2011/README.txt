In order to get this project to compile, several packages need to be installed.  Normally, LED will prompt you to install them once you try to compile your document.  When the prompt comes up, it will have some generic text regarding which repository you will be downloading from.  You need to click the button to choose a repository, select that you want to download from the internet, and then choose a repository.  If you all goes well, LED should automatically download and install the packages.


For some reason LED kept giving me installation errors, so I was forced to directly use the MikTex Package Manager.  To do so, open up a DOS command prompt via the Start button.  The path is:

Start->[All] Programs->Accessories->Command Prompt



Then type the following commands, allowing time for each to download and install the appropriate package:

mpm --verbose --install ms

mpm --verbose --install eso-pic

mpm --verbose --install xcolor



Now you should be able to compile in LED as per usual.